
char* ThisFunctionHasNotBeenTested(int Poor, char* LittleFunction);
